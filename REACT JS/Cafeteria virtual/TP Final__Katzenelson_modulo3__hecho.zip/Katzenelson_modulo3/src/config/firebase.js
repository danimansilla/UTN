import * as firebase from 'firebase'

var firebaseConfig = {
    apiKey: "AIzaSyBzyu6zdSD5_8SWRVHEbZi7RQAhJpzI27s",
    authDomain: "tp-final-7ed62.firebaseapp.com",
    databaseURL: "https://tp-final-7ed62.firebaseio.com",
    projectId: "tp-final-7ed62",
    storageBucket: "tp-final-7ed62.appspot.com",
    messagingSenderId: "353061238275",
    appId: "1:353061238275:web:5682551fbe8305e59f4036",
    measurementId: "G-52WQGD7D4G"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
firebase.db = db;
firebase.auth = firebase.auth();

export default firebase;