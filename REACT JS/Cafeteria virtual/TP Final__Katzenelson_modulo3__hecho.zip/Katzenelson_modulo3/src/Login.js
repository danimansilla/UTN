import React, {Component} from 'react';
import {Form, Button, Card, Row, Col, Container} from 'react-bootstrap';
import history from './history';
import firebase from './config/firebase';

class Login extends Component{

	constructor(props){
		super(props);
		this.state = {
			email:'',
			pass:''
		}
	}

	handleChange(evento){
		const target = evento.target;
		const value = target.value;
		const name = target.name;
		//importante que name de input sea igual que el estado
		this.setState({
			[name]:value
		});
		evento.preventDefault();
	}

	handleSubmit(event){
		let email = this.state.email;
		let pass = this.state.pass;
		firebase.auth.signInWithEmailAndPassword(email,pass)
			.then((data)=>{
				console.log("Login");
				localStorage.setItem('login',true);
				console.log("Log");
				history.push('/');
           	})
			.catch((error)=>{
				console.log("Ocurrio el siguiente error: ", error);
			});
		event.preventDefault();
	}

	render(){
		return(
			<Container>
			<Row  className="justify-content-md-center">
				<Col className="col-4 mt-4">
					<Card>
						<Card.Body>
							<Form className="" onSubmit={this.handleSubmit.bind(this)}>
							    <Form.Group>
							      <Form.Label>Email.</Form.Label>
							      <Form.Control type="text"  placeholder="Ingresar email" name="email" value={this.state.email} onChange={this.handleChange.bind(this)}/>
							    </Form.Group>
							    <Form.Group>
							      <Form.Label>Contraseña</Form.Label>
							      <Form.Control type="password"  placeholder="Ingresar contraseña" name="pass" value={this.state.pass} onChange={this.handleChange.bind(this)}/>
							    </Form.Group>
								<Button type="submit" onClick={this.handleSubmit.bind(this)}>Iniciar sesión</Button>
							</Form>
						</Card.Body>
					</Card>
				</Col>
			</Row>
			</Container>
			)
	}
}

export default Login;