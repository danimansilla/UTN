import React,{Component} from 'react';
import {Button} from 'react-bootstrap';

class Productos extends Component{
	render(){
		return(
			<tr>
				<td>{this.props.id}</td>
				<td>{this.props.producto.nombre}</td>
				<td>{this.props.producto.desc}</td>
				<td>${this.props.producto.precio}</td>
				<td><Button variant="outline-dark" href={'/producto/'+this.props.id}>Ver</Button></td>
			</tr>
			)
	}
}

export default Productos;