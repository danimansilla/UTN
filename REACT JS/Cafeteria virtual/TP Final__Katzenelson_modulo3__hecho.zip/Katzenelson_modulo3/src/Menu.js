import React from 'react';
import {Link} from 'react-router-dom';
import {Navbar, Nav} from 'react-bootstrap';

function Menu(){
	return(
		<Navbar bg="dark" variant="dark">
			<Navbar.Brand href="#home">
				<Navbar.Brand href={'/'}>Red social</Navbar.Brand>
			</Navbar.Brand>
			<Nav className="mr-auto">
				<Navbar.Collapse id="basic-navbar-nav">
					<Nav className="mr-auto">
						<Nav.Link href={'/'}>Home</Nav.Link>
					</Nav>
				</Navbar.Collapse>
			</Nav>
			<Nav>
				<Nav.Link href={'/registro'}>Registro</Nav.Link>
				<Nav.Link href={'/login'}>Login</Nav.Link>
			</Nav>
		</Navbar>
	)
}

export default Menu;