import React,{useState, useEffect} from 'react';
import {Container, Card} from 'react-bootstrap';
import firebase from './config/firebase'

function Producto(props){

	const [datos, setDatos] = useState({});
	//CON CLOUD FIRESTORE
	useEffect(
        () => {
            const id = props.match.params.id;
            firebase.db.doc("productos/"+id)
            .get()
            .then(doc=>{
                setDatos(doc.data())
            })
    });

	return(
        <Container align="center">
            <h2>Producto:</h2>
            <Card style={{ width: '18rem' }}>
                <Card.Body>
                    <Card.Title>{datos.nombre}</Card.Title>
                    <Card.Text>
                    {datos.desc}
                    <br></br>
                    ${datos.precio}
                    </Card.Text>
                </Card.Body>
            </Card>
        </Container>
    )
}

export default Producto;