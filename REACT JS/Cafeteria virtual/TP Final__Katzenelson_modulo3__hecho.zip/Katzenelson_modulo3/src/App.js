import React from 'react';
import logo from './logo.svg';
import './App.css';
import {BrowserRouter, Route} from 'react-router-dom'
import Menu from './Menu.js'
import Home from './Home.js'
import Login from './Login.js'
import Registro from './Registro.js'
import Producto from './Producto.js'

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        {}
        <Route component={Menu} />
        <Route path="/" exact component={Home} />
        <Route path="/login" exact component={Login} />
        <Route path="/registro" exact component={Registro} />
        <Route path="/producto/:id" exact component={Producto}/>
      </BrowserRouter>
    </div>
  );
}

export default App;
