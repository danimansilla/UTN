import React,{Component} from 'react';
import {Table, Spinner,Container} from 'react-bootstrap';
import Productos from './Productos';
import firebase from './config/firebase';
import history from './history';

class Home extends Component{
	constructor(props){
		super(props);
		this.state = {
			productos : [],
			isLoaded: false
		}
	}
	componentDidMount(){
		if(localStorage.getItem("login")){
			firebase.db.collection("productos")
            .get()
            .then(query=>{
                this.setState({
                    productos: query.docs,
                    isLoaded:true
				})
            })
		}else{
			alert("No iniciaste sesión")
			history.push('/login')
        }
	}
	render(){
		if(!this.state.isLoaded){
			return (<Spinner animation="border" role="status"><span className="sr-only">Loading...</span></Spinner>)
		}else{
			return(
			<Container>
				<h2>Productos</h2>
  				<Table striped bordered hover size="sm">
	  			<thead>
						    <tr>
						      <th>SKU</th>
						      <th>Nombre</th>
						      <th>Descripción</th>
						      <th>Precio</th>
						      <th>Acción</th>
						    </tr>
	  			</thead>
	  			<tbody>
					{this.state.productos.map((doc)=><Productos producto={doc.data()} id={doc.id}/>)}
				</tbody>

	  			</Table>
			</Container>
			)
		}
	}
}

export default Home;