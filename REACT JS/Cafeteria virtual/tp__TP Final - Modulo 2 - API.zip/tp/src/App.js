import React,{Component} from 'react';
import './App.css';
import Home from './Componentes/Landing'
import Registrarse from './Componentes/Registrarse'
import Ingresar from './Componentes/Ingresar'
import DetallePerfil from './Componentes/DetallePerfil'
import { BrowserRouter, Route} from "react-router-dom";


class App extends Component{
    constructor(){
        super()
        
    }
    
    render(){

        return (
            <div className="App">
            
                <BrowserRouter>
                    <Route  component={Home} />
                    <Route path="/ingresar" exact  component={()=> <Ingresar title={'test'} />} />
                    <Route path="/registrarse" exact  component={Registrarse} />
                    <Route path="/detalle-perfil/:id" exact  component={DetallePerfil} />
                </BrowserRouter>
            </div>
        );
    }
}

export default App;