import React from 'react';
import {Link} from "react-router-dom";
import home from '../home.jpg';


function Home(){

    return(
        <div>
            <img src={home} className="Registro-home" alt="home" /> 
            <div><Link to={'/registrarse'}>Registrarse</Link></div>  
            <div><Link to={'/ingresar'}>Ingresar</Link></div>       
        </div>
    )
}

export default Home;






