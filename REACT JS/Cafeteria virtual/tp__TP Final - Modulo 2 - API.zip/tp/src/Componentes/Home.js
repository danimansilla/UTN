import React,{Component} from 'react';

import Perfil from './PerfilComponent';

class Home extends Component{
    constructor(){
        super()
        this.state={
            perfiles:[],
            isLoaded:true
        }
    }
    componentDidMount(){
        fetch("https://jsonplaceholder.typicode.com/users")
        .then(res=>res.json())
        .then(
            (result)=>{
                console.log(result)
                this.setState({
                    perfiles:result,
                    isLoaded:false
                })
            }
        ).catch((err)=>{
            console.log(err)
        })
        
    }
    render(){
            return(
                <div>
                    { !this.state.isLoaded && this.state.perfiles.map( p => <Perfil perfil={p} />)}
                </div>
            )  
    }
}

export default Home;