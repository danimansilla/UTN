import React from 'react';

//Componente sin estado (presentacional) sirve como molde para pasar los datos 

function Perfil({perfil}){

    return(
        <div>
            <div>{perfil.name}</div>
            <div>{perfil.email}</div>
        </div>
    )
}

export default Perfil;