
function Menu(){

    return(
        <div>
            <div><Link to={'/registro'}>Registro</Link></div>  
            <div><Link to={'/login'}>Login</Link></div>        
        </div>
    )
}

export default Menu;