import React, {useState, useEffect} from 'react';
import { useHistory } from "react-router-dom";
import {Link} from "react-router-dom";
import {Button} from 'react-bootstrap';


function Registrarse(){
    const history = useHistory();
    const [form, setForm] = useState({usuario:'',password:'',edad:''});
    
    function handleClick(){
        
        history.push("/");
    }
    function handleSubmit(e){
        console.log(form)
        e.preventDefault();
    }
    function handleChange(e){

        const target = e.target;
        const value = target.value
        const name = target.name;

      
        setForm({
            ...form,
            [name] : value});
        
    }
    return(
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Usuario: </label>
                    <input type="text" name="usuario" value={form.usuario} onChange={handleChange}></input>
                </div>
                
                <div>
                    <label>Contraseña: </label>
                    <input type="password" name="password" value={form.password} onChange={handleChange}></input>
                    
                </div>
                <div>
                    <label>Edad: </label>
                    <input type="number" name="Edad" value={form.edad} onChange={handleChange}></input>
                    
                </div>
                <br></br>
            </form>
            <button onClick={handleClick} >Ir a Home</button>
            <Link to='/Perfil'><Button>Registrarse</Button></Link>
        </div>
    )
}

export default Registrarse;


