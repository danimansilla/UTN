import React, {useState, useEffect} from 'react';
import Perfil from './PerfilComponent'

function DetallePerfil(props){
    
    const [datos, setDatos] = useState({});
    
    useEffect(
        () => {
            fetch("https://jsonplaceholder.typicode.com/users/" + props.match.params.id)
            .then(res=>res.json())
            .then(
                (result)=>{
                    console.log(result)
                    setDatos(result)
                }
            ).catch((err)=>{
                console.log(err)
            })
    }, []); 
    
    return(
        <div>
              <Perfil perfil = {datos}/>
        </div>
    )
}

export default DetallePerfil;