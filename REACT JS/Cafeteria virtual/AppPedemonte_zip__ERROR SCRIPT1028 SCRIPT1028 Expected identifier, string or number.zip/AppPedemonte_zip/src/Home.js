import React, {Component} from 'react';
import Perfil from './Perfil';
import firebase from './Config/firebase'

 class Home extends Component {
   constructor() {
     super()
     this.state= {
       perfiles:[],
       isLoaded:false
     }
   }
  componentDidMount() {
    if(localStorage.getItem("login")){
      firebase.db.collection("usuarios")
      .get()
      .then(querySnapshot=> {
        console.log("hola",querySnapshot.docs)
        this.setState({
          pefiles:querySnapshot.docs,
          isLoaded: true
        })
      })
    }

 }


   render(){

       return(
      <div>
      {! this.state.isLoaded &&
       <div>
       Loading...
       </div>
      }
      { this.state.isLoaded &&
       <div>
       hola
       {this.state.perfiles.map((doc)=><Perfil datos={doc.data()} id={doc.id}/>)}
       </div>
       }
       </div>
        )
  }
}

export default Home;
