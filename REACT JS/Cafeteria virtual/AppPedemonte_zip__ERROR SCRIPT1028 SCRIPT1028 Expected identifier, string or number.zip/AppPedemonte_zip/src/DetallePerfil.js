
import React, {useState, useEffect} from 'react';
import firebase from './Config/firebase';


function DetallePerfil(props) {
  const [datos, setDatos]= useState({});
  useEffect(
    ()=> {
      const id = props.match.params.id;
      firebase.db.doc("usuarios/"+id)
      .get()
      .then(doc=> {
        setDatos(doc.data())
        console.log(doc.data())
      } )

    }, [] );

    const handleClick = ()=> {
      const id = props.match.params.id;
      firebase.db.doc("usuarios/"+id)
      .delet()
      .then(doc=> {
        setDatos(doc.data())
        console.log(doc.data())
      } )
    }

 return(
  <div>
  <div>{datos.nombre}</div>
  <div>{datos.apellido}</div>
  <div>{datos.email}</div>
  </div>
 )

}


export default DetallePerfil;
