import React from 'react';
import {Link} from "react-router-dom";

function Perfil({datos, id}) {
console.log(datos)
return(
  <div>
   <div>{datos.name}</div>
  <div> {datos.email}</div>
   <Link to={'detalle-perfil/'+id}>Ver Detalle</Link>
  </div>
 )

}


export default Perfil;
