import React, {Component} from 'react';
import {Form, Button} from 'react-bootstrap';
import firebase from './Config/firebase';
import {withRouter} from 'react-router-dom';


class  Login extends Component {
  constructor(props){
    super(props);
    console.log(this.props.title)
    this.handleSubmit = this.handleSubmit.bind(this)
    this.handleChange = this.handleChange.bind(this)
    this.state={
      usuario:'',
      password:'',
      email:''
    }
  }

  handleSubmit(e){
  firebase.auth.signInWithEmailAndPassword(this.state.email, this.state.password)
  .then((data)=> {
    console.log("Login")
    localStorage.setItem('login', JSON.stringify(data.user))
    const {history} = this.props;
    history.push('/');
  })
   .catch(error => {
     console.log("Error", error)
   });
   e.preventDefault();

  }
  handleChange(e){
    const target= e.target;
    const value= target.value
    const name= target.name;
    this.setState({
      [name]: value
    })
    e.preventDefault();

  }

  render(){
  return(
    <div>
    <Form onSubmit={this.handleSubmit}>
    <Form.Group controlId="formBasicEmail">
      <Form.Label>Usuario</Form.Label>
      <Form.Control type="text" placeholder="Ingrese su Usuario"
      name="usuario" value={this.state.usuario}
       onChange={this.handleChange} />
      <Form.Text className="text-muted">
        We'll never share your name with anyone else.
      </Form.Text>
    </Form.Group>

  <Form.Group controlId="formBasicEmail">
    <Form.Label>Email address</Form.Label>
    <Form.Control type="email" placeholder="Enter email"
    name="email" value={this.state.email}
     onChange={this.handleChange} />
    <Form.Text className="text-muted">
      We'll never share your email with anyone else.
    </Form.Text>
  </Form.Group>

  <Form.Group controlId="formBasicPassword">
    <Form.Label>Password</Form.Label>
    <Form.Control type="password" placeholder="Password"
    name="password" value={this.state.password}
     onChange={this.handleChange} />
  </Form.Group>
  <Form.Group controlId="formBasicCheckbox">
   <Form.Check type="checkbox" label="Check me out" />
  </Form.Group>
  <Button variant="primary" type="submit">
    Submit
  </Button>
</Form>
    </div>
  )

    }
  }

  export default withRouter (Login);
