import React, {Component} from 'react';
import './App.css';
import Home from './Home';
import { BrowserRouter, Route} from "react-router-dom";
import Menu from './Menu'
import Registro from './Registro'
import DetallePerfil from './DetallePerfil'
import Login from './Login'
import 'bootstrap/dist/css/bootstrap.min.css';


  class App extends Component {
  constructor() {
   super()


  }

  render() {
  return (
    <div className="App">
    <BrowserRouter>
    <Route  component={Menu}/>
    <Route path="/" exact component={Home}/>
    <Route path="/registro" exact component={Registro}/>
    <Route path="/login" exact component={Login}/>
    <Route path="/detalle-perfil/:id" exact component={DetallePerfil}/>

    </BrowserRouter>
    </div>
  );
 }
}

export default App;
