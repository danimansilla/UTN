import * as firebase from 'firebase'
// Your web app's Firebase configuration
 var firebaseConfig = {
   apiKey: "AIzaSyARDoUT97pFEwGBlquK4vPo49lHpT89SUg",
   authDomain: "er-proyecto-dc232.firebaseapp.com",
   databaseURL: "https://er-proyecto-dc232.firebaseio.com",
   projectId: "er-proyecto-dc232",
   storageBucket: "er-proyecto-dc232.appspot.com",
   messagingSenderId: "201222340117",
   appId: "1:201222340117:web:4629959f97c4880c68981c"
 };

 // Initialize Firebase
 //if(!firebase.apps.length){
 firebase.initializeApp(firebaseConfig);
 const db = firebase.firestore();
 //db.settings({
//  timestampsInSnapshots: true
 //});
//}
firebase.auth = firebase.auth();
firebase.db=db;
export default firebase;
