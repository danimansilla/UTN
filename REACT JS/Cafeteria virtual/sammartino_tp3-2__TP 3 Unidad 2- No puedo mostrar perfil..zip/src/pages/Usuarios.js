import React, {Component} from 'react';
import { Link } from 'react-router-dom';

import '../css/styleExtra.css';
// import ReactDOM from 'react-dom';

class Usuarios extends Component {
    // constructor(){
    constructor(props){
        // super()
        super(props)
        console.log(this.props.datos)
    }

    render(){
        return(
            <div class="cuadroAmigo">  
                <div>
                    <Link to={'detalle-perfil/'+this.props.datos.id}><img src={this.props.datos.img} alt="foto"></img></Link>
                </div>   
                {/* <div>{this.props.datos.id}</div>
                <div>{this.props.datos.name}</div>
                <div>{this.props.datos.lastName}</div> */}
            </div>
        )
    }
}
export default Usuarios;