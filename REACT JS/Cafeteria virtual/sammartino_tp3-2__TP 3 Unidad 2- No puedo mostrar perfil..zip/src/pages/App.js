import React, { Component } from 'react';

import {Route} from 'react-router';
import {BrowserRouter} from 'react-router-dom';
import '../css/App.css';
import Home from '../pages/Home';
import DetallePerfil from '../pages/Detalle-Perfil';
import '../css/styleExtra.css';

class App extends Component {

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <h1>
            Home
          </h1>
        </header>

        <div className="Contenido">
          <div className="Home">
            <BrowserRouter>
              <Route path="/" exact component={Home} />
              <Route path="/detalle-perfil/:id" exact component={DetallePerfil} />
              {/* <Route path="/usuarios" component={Usuarios} /> */}
            </BrowserRouter>

          </div>
        </div>
      </div>
    );
  }
}
export default App;
