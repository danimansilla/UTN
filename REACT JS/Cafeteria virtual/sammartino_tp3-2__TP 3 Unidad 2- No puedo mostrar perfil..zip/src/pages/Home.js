import React, { Component } from 'react';
// import ReactDOM from 'react-dom';
import Usuarios from './Usuarios';

class Home extends Component {
    perfiles;
    constructor(props) {
        super(props)
        this.state = {
            error: null,
            isLoaded: false,
            perfiles: []
        };
    }

    componentDidMount(){
        fetch("./perfiles.json")
        .then(res => res.json())
        .then(
            (result) => {
                console.log(result)
                this.setState({
                    isLoaded: true,
                    perfiles: result
                });
            },
            (error) => {
                console.log(error)
                this.setState({
                    isLoaded: true,
                    error
                });
            }
        )
    }

    render(){       
        const {error, isLoaded, perfiles } = this.state;
        if(error) {
            return <div>Error: {error.message}</div>
        } else if (!isLoaded) {
            return <div>Loading...</div>;
        }else {
            return(
                <ul>
                    {perfiles.map(
                        data=><Usuarios datos={data} />
                    )}
               </ul>
            )
        }
    }

}

export default Home;