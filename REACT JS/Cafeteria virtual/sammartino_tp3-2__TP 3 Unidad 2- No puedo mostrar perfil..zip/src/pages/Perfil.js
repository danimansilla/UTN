import React, {Component} from 'react';
import '../css/styleExtra.css';
// import ReactDOM from 'react-dom';

class Perfil extends Component {   
    constructor(props){      
        super(props)
        console.log(props.match.params.id)
    }

    render(){
        return(
            <div class="cuadroAmigo"> 
                
                
                <div><img src={this.props.match.img} alt="foto"></img></div>   
                <div>{this.props.match.id}</div>
                <div>{this.props.match.name}</div>
                <div>{this.props.match.lastName}</div>
            </div>
        )
    }
}
export default Perfil;