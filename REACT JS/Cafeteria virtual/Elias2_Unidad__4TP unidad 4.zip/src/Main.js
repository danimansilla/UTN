import React from "react";
import { FaReact } from "react-icons/fa";

function Main() {
  return (
    <div>
      <main className="mainApp">
        <img
          className="fotoUsuario"
          src="https://daro007.github.io/Portfolio/fotoPerfil.jpg"
          alt="foto perfil de usuario Dario Elias"
        />
        <div>
          <p>
            <br />
            <br />
            <span>Usuario:</span> Dario Nicolas Elias
          </p>

          <p>
            <span>Ciudad:</span> Rosario
          </p>
          <p>
            <span>Curso:</span> Desarrollo en React JS <FaReact></FaReact>
          </p>
        </div>
      </main>
    </div>
  );
}

export default Main;
