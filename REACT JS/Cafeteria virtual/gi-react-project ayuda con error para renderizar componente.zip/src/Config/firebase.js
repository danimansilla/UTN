import * as firebase from 'firebase';

var firebaseConfig = {
    apiKey: "AIzaSyCfsSY2ZeZM7DF2R6fKWt2qfoRq6USaArc",
    authDomain: "gi-react.firebaseapp.com",
    databaseURL: "https://gi-react.firebaseio.com",
    projectId: "gi-react",
    storageBucket: "gi-react.appspot.com",
    messagingSenderId: "146910387901",
    appId: "1:146910387901:web:5acbaebc556613e83b61d4",
    measurementId: "G-8LXVK2VWJL"
};

if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
    firebase.analytics();
}

const db = firebase.firestore();

firebase.db = db;
firebase.auth = firebase.auth();

export default firebase;
