import React, { Component } from 'react';
import { Card, Button, Badge, Alert } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import firebase from '../Config/firebase';
import Loading from '../Components/Loading';

class DetalleProducto extends Component {
    constructor(props){
        super(props);
        this.handleClick = this.handleClick.bind(this);
        this.state = {
            login: false,
            isLoaded: false,
            producto: null
        }
    }

    traerProducto = async () => {
        var productos_mostrar = [];
        var storageRef = firebase.storage().ref();

        
        const prod = await firebase.db.doc("productos/" + this.props.match.params.uidProducto).get();           
        const imgUrl = await storageRef.child('/img/productos/'+ prod.get("sku") + '.jpg').getDownloadURL();
        let producto = {
            nombre: prod.get("nombre"),
            descripcion: prod.get("descripcion"),
            precio: prod.get("precio"),
            sku: prod.get("sku"),
            img: imgUrl
        }
        this.setState({
            isLoaded: true,
            producto: producto
        });
    } 

    componentDidMount(){
        var user = firebase.auth.currentUser;

        if (user) {
            this.traerProducto();
            this.setState({
                    login: true
            })
        } else {
            this.setState({
                login: false
            })
        }
    }

    handleClick(){
        return true;
    }


    render() {
        const estado = this.state;
        if (estado.login === true && estado.producto) {
            return (
                <Card style={{
                 maxWidth: '500px',
                 margin: '0 auto'
                }}>
                    <Card.Img variant="top" src={estado.producto.img} />
                    <Card.Body>
                        <Card.Title>{estado.producto.nombre}&nbsp; <Badge variant="secondary">U$S {estado.producto.precio.toLocaleString()}</Badge></Card.Title>
                        <Card.Subtitle className="mb-2 text-muted">sku:<i>&nbsp;{estado.producto.sku}</i> &nbsp;</Card.Subtitle>
                        <Card.Text>
                            {estado.producto.descripcion}
                        </Card.Text>
                        
                        <Button variant="primary">Agregar 🎷</Button>&nbsp;
                        <Button as={Link} to={"/home"} variant="primary">🎼 Volver al inicio</Button>
                    </Card.Body>
                </Card>
            ) 
        } else if (estado.login === true && !estado.producto) {
            return <Loading />;
        } else {
            return(
                <>
                    <Alert variant='danger'>
                        Debe ingresar al sistema para poder visualizar esta página.
                    </Alert>
                    <Button as={Link} to={"/home"} variant="primary"> 🎼 Ir al inicio</Button>&nbsp;
                    <Button as={Link} to={"/login"} variant="primary">🎙 Ingresar</Button>&nbsp;
                    <Button as={Link} to={"/registro"} variant="primary">🎶 Crear cuenta</Button>
                </>
            ) 
        }
    }
}

export default DetalleProducto;