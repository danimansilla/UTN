import React, { Component } from 'react';
import firebase from '../Config/firebase';
import ItemProducto from '../Components/ItemProducto';
import Loading from '../Components/Loading';
import { CardDeck } from 'react-bootstrap';

class Home extends Component {
    constructor() {
        super();
        this.state = {
            error: null,
            isLoaded: false,
            productos: null
        }
    }

    traerProductos = async () => {
        var productos_mostrar = [];
        var storageRef = firebase.storage().ref();

        const productos = await firebase.db.collection('productos').get();
        await productos.forEach(async function(doc) {
                
                const imgUrl = await storageRef.child('/img/productos/'+ doc.data().sku + '.jpg').getDownloadURL();
                let p = {
                    id: doc.id,
                    nombre: doc.data().nombre,
                    descripcion: doc.data().descripcion,
                    precio: doc.data().precio,
                    sku: doc.data().sku,
                    img: imgUrl
                }
                
                productos_mostrar.push(p);
                this.setState({
                    isLoaded: true,
                    productos: productos_mostrar
                });
        }, this);
    }    

    componentDidMount() {
        this.traerProductos();  
    }

    render() {
        const { error, isLoaded, productos } = this.state;
        if (productos != null) {
            if (error) {
                return <div>Error: {error.message}</div>;
            } else if (!isLoaded || !productos) {
                return <Loading />;
            } else {
                return (
                    <section className="Home">
                        <h1>Productos destacados</h1>
                        <p>Haga click en cada producto para ver el detalle</p>
                        <CardDeck>
                            {productos.map((producto, index) => <ItemProducto key={index} datos={producto} /> )}
                        </CardDeck>
                    </section>
                );
            }
        } else {
            return  <Loading />;
        }
    }
}
export default Home;