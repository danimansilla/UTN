import React, { Component } from 'react';
import { Card, Button, Badge } from 'react-bootstrap';
import { Link } from 'react-router-dom';

class ItemProducto extends Component {
    constructor(props){
        super(props);
    }

    render() {
        return (
            <Card>
                <Card.Img variant="top" src={this.props.datos.img} />
                <Card.Body>
                    <Card.Title>{this.props.datos.nombre}&nbsp; <Badge variant="secondary">U$S {this.props.datos.precio.toLocaleString()}</Badge></Card.Title>
                    <Card.Subtitle className="mb-2 text-muted">sku:<i>&nbsp;{this.props.datos.sku}</i> &nbsp;</Card.Subtitle>
                    <Card.Text>
                        {this.props.datos.descripcion}
                    </Card.Text>
                    
                    <Button as={Link} to={"/producto/"+this.props.datos.id} variant="primary">Ver detalle 🎺</Button>
                </Card.Body>
            </Card>

        );
    }
}

export default ItemProducto;