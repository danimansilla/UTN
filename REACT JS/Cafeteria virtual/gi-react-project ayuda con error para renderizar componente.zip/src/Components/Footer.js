import React, { Component } from 'react';
import { Navbar } from 'react-bootstrap';

class Footer extends Component {
    render() {
        return (
            <footer className="Footer">
                <Navbar bg="dark" variant="dark" collapseOnSelect expand="sm" sticky="bottom">
                    <Navbar.Brand href="#home">Desarrollado por GI - 2020 &copy; // Curso React UTN-FRBA</Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                </Navbar>
                <h3> </h3>
            </footer>
        );
    }
}

export default Footer;