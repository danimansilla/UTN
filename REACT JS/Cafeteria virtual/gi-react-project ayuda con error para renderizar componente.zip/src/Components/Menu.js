import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Navbar, Nav, NavDropdown } from 'react-bootstrap';
import firebase from '../Config/firebase';

class Menu extends Component {
    constructor() {
        super();
        this.state = {
            login: false,
            user: '',
            userData: ''
        }
    }

    componentDidMount(){
        firebase.auth.onAuthStateChanged((user) => {
            if (user) {
                // User is signed in.
                //console.log("usuario con uid:" + user.uid);
                firebase.db.collection("usuarios")
                    .where("uid","==",user.uid)
                    .get()
                    .then(query => {
                        query.forEach((d) => {
                            //console.log(d.data().username);
                            this.setState({
                                login: true,
                                user: user,
                                userData: d.data() 
                            });
                        });
                    })
                    .catch(function(error) {
                        console.log("Error getting document:", error);
                    });               
            } else {
                // No user is signed in.
                this.setState({
                    login: false,
                    user: '',
                    userData: ''
                });
            }
        });
    }
    
    render() {
        const login = this.state.login;
        const userData = this.state.userData;

        return (
            <Navbar bg="primary" variant="dark" collapseOnSelect expand="sm" sticky="top"> 
                <Navbar.Brand as={Link} to="/home">
                    <img
                        alt=""
                        src="../logo.png"
                        width="50"
                        height="50"
                        className="d-inline-block align-center"
                    />{' '}
                    GI Music Shop
                </Navbar.Brand>
                <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                <Navbar.Collapse id="responsive-navbar-nav">
                    <Nav className="mr-auto">
                        <Nav.Link as={Link} to="/home">🎼 Inicio</Nav.Link>
                    </Nav>
                    <Nav className="justify-content-end">
                    {
                        !login && 
                            <>
                                
                                    <Nav.Link as={Link} to="/login">🎙 Ingresar</Nav.Link>
                                    <Nav.Link as={Link} to="/registro">🎶 Crear cuenta</Nav.Link>
                            </>
                    }
                    {
                        login &&
                            <>
                                <NavDropdown drop="left" title={"🎵 "+userData.username} id="basic-nav-dropdown">
                                <NavDropdown.Item as={Link} to="/miperfil">🎸 Mi perfil</NavDropdown.Item>
                                <NavDropdown.Item href="#">🎷 Carrito de compras</NavDropdown.Item>
                                <NavDropdown.Divider />
                                <NavDropdown.Item as={Link} to="/logout">🎧 Cerrar sesión</NavDropdown.Item>
                                </NavDropdown>
                            </>
                    }
                    </Nav>
                    
                </Navbar.Collapse>
            </Navbar>
        );
    }
}

export default Menu;
