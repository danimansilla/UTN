
import React from 'react';
import { BrowserRouter as Router, Route, Redirect } from "react-router-dom";
import MainMenu from '../components/MainMenu';
import Home from '../pages/Home';
import Login from '../pages/Login';
import Sorteo from '../pages/Sorteo';

export default () => {
  return (
    <Router>
      <MainMenu />
      <Route path="/" exact component={Home} />
      <Route path="/login/" exact component={Login} />
      <Route path="/sorteo/" exact component={Sorteo} />
      <Route render={() => <Redirect to="/" />} />
    </Router>
  );
}
