import React from 'react';
import './App.css';

import AppRouter from './components/Router';

function App() {
  return (
    <AppRouter />
  );
}

export default App;
