
import React from 'react';
import { useHistory } from 'react-router-dom';

export default () => {
  const history = useHistory();

  return (
    <>
      <h1>Home</h1>
      <button onClick={()=>history.push('/sorteo')}>Hacer Sorteo</button>
    </>
  );
}   
  