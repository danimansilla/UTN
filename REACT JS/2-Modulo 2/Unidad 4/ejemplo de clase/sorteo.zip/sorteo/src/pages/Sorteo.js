
import React, {useState, useEffect} from 'react';

export default () => {

  const [listaPaises, setListaPaises] = useState([]);
  const [pais1, setPais1] = useState({name:''});
  const [pais2, setPais2] = useState({name:''});

  const hacerSorteo = (listaPaises) => {
    if(listaPaises){
      return listaPaises[Math.floor(Math.random() * (listaPaises.length - 0)) + 0];
    }
  }

  useEffect(
    ()=>{
      fetch('https://restcountries.eu/rest/v2/all')
      .then(res=>res.json())
      .then(res=>{
        if(res){
          setPais1(hacerSorteo(res));
          setPais2(hacerSorteo(res));
        }
      })
      .catch(error=>{
        console.error(error);
      })
    },[listaPaises]
  );

  return (
    <>
    <h1>Sorteo</h1>
    <button onClick={()=>setListaPaises([])}>Hacer sorteo</button>
    <ul>
      <li>{pais1.name}</li>
      <li>{pais2.name}</li>
    </ul>
    </>
  );
}   
  