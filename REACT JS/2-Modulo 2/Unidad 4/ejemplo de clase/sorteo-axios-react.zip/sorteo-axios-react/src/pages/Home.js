
import React from 'react';
import { useHistory } from 'react-router-dom';
import { Jumbotron, Button} from 'react-bootstrap';

export default () => {
  const history = useHistory();

  return (
    <Jumbotron style={{margin:20}}>
      <h1>Sorteo de paises</h1>
      <p>
        Este es un sistema para sortear paises
      </p>
      <p>
        <Button onClick={()=>history.push('/sorteo')}>Hacer Sorteo</Button>
      </p>
    </Jumbotron>
  );
}
