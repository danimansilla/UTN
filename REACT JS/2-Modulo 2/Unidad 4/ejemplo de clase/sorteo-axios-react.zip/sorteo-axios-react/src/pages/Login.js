
import React from 'react';

export default () => {
  return (
    <form>
      <label>
        Username:
        <input type="text" name="name" />
      </label>
      <label>
        Password:
        <input type="password" name="password" />
      </label>
      <input type="submit" value="Submit" />
    </form>
  );
}
