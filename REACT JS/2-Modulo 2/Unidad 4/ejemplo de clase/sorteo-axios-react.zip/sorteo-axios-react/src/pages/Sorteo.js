
import React, { useState, useEffect } from 'react';
import { Jumbotron, Container, Card, Button, Row, Col } from 'react-bootstrap';
import axios from 'axios';

export default () => {

  const [listaPaises, setListaPaises] = useState([]);
  const [pais1, setPais1] = useState({ name: '', flag: '', region: '' });
  const [pais2, setPais2] = useState({ name: '', flag: '', region: '' });

  const hacerSorteo = (listaPaises) => {
    if (listaPaises) {
      return listaPaises[Math.floor(Math.random() * (listaPaises.length - 0)) + 0];
    }
  }

  useEffect(
    () => {
      axios.get('https://restcountries.eu/rest/v2/all', {
        timeout: 1
      })
      .then(function (response) {
        setPais1(hacerSorteo(response.data));
        setPais2(hacerSorteo(response.data));
        console.log(response);
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      })
      .then(function () {
        // always executed
      });      
    }, [listaPaises]
  );

  return (
    <Jumbotron fluid>
      <Container>
        <h1>Sorteo</h1>
        <p>
          <button onClick={() => setListaPaises([])}>Hacer sorteo</button>
        </p>
        <Row>
          <Col>
          <Card style={{ width: '18rem' }}>
            <Card.Img variant="top" src={pais1.flag} />
            <Card.Body>
              <Card.Title>{pais1.name}</Card.Title>
              <Card.Text>
                Region: {pais1.region}
              </Card.Text>
              <Button variant="primary">Go somewhere</Button>
            </Card.Body>
          </Card>
          </Col>
          <Col>
            <Card style={{ width: '18rem' }}>
              <Card.Img variant="top" src={pais2.flag} />
              <Card.Body>
                <Card.Title>{pais2.name}</Card.Title>
                <Card.Text>
                  Region: {pais2.region}
                </Card.Text>
                <Button variant="primary">Go somewhere</Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </Jumbotron>
  );
}
