import React from 'react';
import logo from './logo.svg';
import './App.css';

import AppRouter from './components/Router';

function App() {
  return (
    <AppRouter />
  );
}

export default App;
