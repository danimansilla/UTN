import React, {useState, useEffect} from 'react'

function ContenidoFuncion(){   

    const [texto, setTexto] = useState('');
    const [otro, setOtro] = useState('');

    useEffect(
        () => {
        console.log('componentDidMount - hook equivalente');
    }, []);    

    useEffect(
        () => {
        console.log('componentDidUpdate - hook equivalente');
    });   

    useEffect(
        () => {
        console.log('componentDidUpdate - Solo si cambia el estado texto');
    }, [texto]);   

    useEffect(() => {
        return ()=>{
            console.log('componentWillUnmount - hook equivalente');
        }
    },[]); 
        
    return(
        <div>
            <p>Contenido Función {texto}</p>
            <button onClick={()=>setTexto('HOLA')}>Agregar hola</button>
            <button onClick={()=>setTexto('')}>Quitar hola</button>
        </div>
    )
}
export default ContenidoFuncion