import React, {Component} from 'react'

class ContenidoClase extends Component{
    constructor(props){
        super(props);
        this.state = {texto: ''};
    }

    componentDidMount(){
        console.log("componentDidMount");
    }

    componentDidUpdate(){
        console.log("componentDidUpdate");
    }

    componentWillUnmount(){
        console.log("componentWillUnmount");
    }

    render(){
        return(
            <div>
                <p>Contenido Clase {this.state.texto}</p>
                <button onClick={()=>this.setState({texto:'HOLA'})}>Agregar hola</button>
                <button onClick={()=>this.setState({texto:''})}>Quitar hola</button>
            </div>
        )
    }    
}
export default ContenidoClase